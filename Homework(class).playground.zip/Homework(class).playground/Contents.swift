import UIKit

enum autoran {
    case on, off
}

class Car {
    
   var color: String
   var maxSpeed: Int
   var horsePower: Int
   var autoran: String
    
    init(color: String, maxSpeed: Int, horsePower: Int, autoran: String) {
    
    self.color = color
    self.maxSpeed = maxSpeed
    self.horsePower = horsePower
    self.autoran = autoran
        
    }
}

class sportCar: Car {
    
    enum hatchState {
        case open, close
    }

    var hatchState: String
     init(hatchState: String){
      self.hatchState = hatchState
        super.init(color: "turquoise", maxSpeed: 410, horsePower: 1600, autoran: "on")
    }
}

var Koenigsegg = sportCar(hatchState:"open")

print(Koenigsegg.color)
print(Koenigsegg.maxSpeed)
print(Koenigsegg.horsePower)
print(Koenigsegg.autoran)
print(Koenigsegg.hatchState)

class trunkCar: Car {
    
    enum trailer {
        case fixed, notFixed
    }
    
    var trailer: String
    init(trailer: String){
      self.trailer = trailer
       super.init(color:"black", maxSpeed: 100, horsePower:480, autoran: "off")
    }
}

var Man = trunkCar(trailer:"notFixed")

print(Man.color)
print(Man.maxSpeed)
print(Man.horsePower)
print(Man.autoran)
print(Man.trailer)
