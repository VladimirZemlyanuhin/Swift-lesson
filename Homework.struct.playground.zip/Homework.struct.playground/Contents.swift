import UIKit

enum engine {
    
    case on, off
}

enum windows {
    
    case open, close
}

struct Car {
    let model: String
    let year: Int
    var trunkVolume: Int
    var engine: engine {
        willSet {
            if newValue == .on{
                print("Двигатель запущен")
            }else{
                print("Двигатель заглушен")
            }
        }
    }
var windows: windows
    
    mutating func openWindows() {
        self.windows = .open
    }
    mutating func closeWindows() {
        self.windows = .close
    }
}
 
var car1 = Car(model: "Skoda", year: 2017,trunkVolume: 568, engine: .off, windows: .close)
var car2 = Car(model: "Man", year:2020, trunkVolume: 3375, engine: .on, windows: .open)

print(car1.model)
print(car1.year)
print(car1.trunkVolume)
print(car1.engine)
print(car1.windows)

print(car2.model)
print(car2.year)
print(car2.trunkVolume)
print(car2.engine)
print(car2.windows)

